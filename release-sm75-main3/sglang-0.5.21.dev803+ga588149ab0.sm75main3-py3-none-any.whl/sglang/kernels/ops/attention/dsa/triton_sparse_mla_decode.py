"""Triton sparse MLA decode kernel with FP8 and BF16 KV cache support.

Adapted from aiter's unified_attention_sparse_mla kernel for DSA shapes:
  q:       [bs, H, DIM]     fp8/bf16 (DIM=576 = D_V+D_TAIL)
  kv:      [num_pages, 1, DIM]  fp8/bf16
  indices: [bs, 1, topk]    int32
  output:  [1, bs, H, D_V]  bf16

Two variants:
  1. Base: single-pass per-token kernel (adapted from aiter)
  2. Split-K: adaptive split-K with fused fast path (adapted from DSv4)
"""

import torch
import triton
import triton.language as tl

from sglang.kernels.ops.attention.dsa.triton_sparse_mla import (
    _PREFERRED_BLOCK_K,
    _cu_count,
    _gfx950_sparse_mla_kv_splits,
    _gfx950_sparse_mla_num_warps,
    _is_gfx950_sparse_mla_fp8,
    _kv_splits_heuristic,
    _next_pow2,
    _no_async_copy,
    _page_offsets_fit_i32,
    _reduce_d_chunk,
    _row_strides,
    _sparse_mla_block_k,
    _sparse_mla_reduce_kernel,
    _validate_input_dtypes,
)
from sglang.kernels.ops.quantization.fp8_kernel import is_fp8_fnuz

_IS_FNUZ = is_fp8_fnuz()
_FP8_MAX = 240.0 if _IS_FNUZ else 448.0
_G = tl.constexpr(128)

_SplitKWorkspace = list[tuple[torch.Tensor, torch.Tensor]]
_splitk_bufs: dict[tuple[torch.device, int], _SplitKWorkspace] = {}


def _gfx950_sparse_mla_decode_tile_config(
    base_ctas: int, topk: int, block_k: int, max_kv_splits: int
) -> tuple[int, int]:
    if topk == 2048 and base_ctas <= 2:
        block_k = 32
        if base_ctas == 1:
            max_kv_splits = 64
    return block_k, max_kv_splits


def _get_splitk_bufs(
    bs: int,
    kv_splits: int,
    h_padded: int,
    d_v: int,
    device: torch.device,
    workspace: _SplitKWorkspace | None = None,
) -> tuple[torch.Tensor, torch.Tensor]:
    if workspace is None:
        stream_id = int(torch.cuda.current_stream(device).cuda_stream)
        workspace = _splitk_bufs.setdefault((device, stream_id), [])

    needed_lse = bs * kv_splits * h_padded
    needed_acc = bs * kv_splits * h_padded * d_v
    for lse_buf, acc_buf in reversed(workspace):
        if lse_buf.numel() >= needed_lse and acc_buf.numel() >= needed_acc:
            lse = lse_buf[:needed_lse].view(bs, kv_splits, h_padded)
            acc = acc_buf[:needed_acc].view(bs, kv_splits, h_padded, d_v)
            return lse, acc

    # Keep old allocations alive because captured graphs retain their pointers;
    # round up so a growing shape sequence adds O(log range) buffers, not one each.
    capacity_lse = _next_pow2(max(needed_lse, 2 * _cu_count(device) * 16))
    lse_buf = torch.empty(capacity_lse, dtype=torch.float32, device=device)
    acc_buf = torch.empty(capacity_lse * d_v, dtype=torch.bfloat16, device=device)
    workspace.append((lse_buf, acc_buf))
    lse = lse_buf[:needed_lse].view(bs, kv_splits, h_padded)
    acc = acc_buf[:needed_acc].view(bs, kv_splits, h_padded, d_v)
    return lse, acc


# ---------------------------------------------------------------------------
# Split-K kernel (adapted from DSv4 paged_decode.py)
# ---------------------------------------------------------------------------

LOG2E = 1.4426950408889634


@triton.jit
def _sparse_mla_decode_fused_kernel(
    q_nope_ptr,  # [N, H, D_V]
    q_rope_ptr,  # [N, H, D_TAIL]
    kv_ptr,  # [num_pages, 1, KV_DIM]
    idx_ptr,  # [N, topk]
    out_ptr,  # [N, H, D_V]
    qk_scale,
    fp8_max,
    topk: tl.constexpr,
    H: tl.constexpr,
    KV_DIM: tl.constexpr,
    D_V: tl.constexpr,
    D_TAIL: tl.constexpr,
    NUM_GROUPS: tl.constexpr,
    STRIDE_QN_T: tl.constexpr,
    STRIDE_QN_H: tl.constexpr,
    STRIDE_QR_T: tl.constexpr,
    STRIDE_QR_H: tl.constexpr,
    USE_FP8_DOT: tl.constexpr,
    BLOCK_H: tl.constexpr,
    BLOCK_K: tl.constexpr,
    USE_I64_PAGE: tl.constexpr = True,
):
    t = tl.program_id(0)
    pid_h = tl.program_id(1)

    h_offs = pid_h * BLOCK_H + tl.arange(0, BLOCK_H)
    h_mask = h_offs < H
    dt = tl.arange(0, D_TAIL)
    g = tl.arange(0, _G)

    input_type = kv_ptr.dtype.element_ty if USE_FP8_DOT else tl.bfloat16
    if USE_FP8_DOT:
        p_dot_scale = 1.0 / fp8_max
    else:
        p_dot_scale = 1.0

    qn_base = q_nope_ptr + t * STRIDE_QN_T
    qn_row = qn_base + h_offs[:, None] * STRIDE_QN_H
    q0 = tl.load(
        qn_row + g[None, :],
        mask=h_mask[:, None],
        other=0.0,
    ).to(input_type)
    if NUM_GROUPS >= 2:
        q1 = tl.load(
            qn_row + (_G + g)[None, :],
            mask=h_mask[:, None],
            other=0.0,
        ).to(input_type)
    if NUM_GROUPS >= 3:
        q2 = tl.load(
            qn_row + (2 * _G + g)[None, :],
            mask=h_mask[:, None],
            other=0.0,
        ).to(input_type)
    if NUM_GROUPS >= 4:
        q3 = tl.load(
            qn_row + (3 * _G + g)[None, :],
            mask=h_mask[:, None],
            other=0.0,
        ).to(input_type)
    q_tail = tl.load(
        q_rope_ptr + t * STRIDE_QR_T + h_offs[:, None] * STRIDE_QR_H + dt[None, :],
        mask=h_mask[:, None],
        other=0.0,
    ).to(input_type)

    neg_large = -3.4028234663852886e38
    m_i = tl.full((BLOCK_H,), neg_large, dtype=tl.float32)
    l_i = tl.zeros((BLOCK_H,), dtype=tl.float32)
    acc0 = tl.zeros((BLOCK_H, _G), dtype=tl.float32)
    if NUM_GROUPS >= 2:
        acc1 = tl.zeros((BLOCK_H, _G), dtype=tl.float32)
    if NUM_GROUPS >= 3:
        acc2 = tl.zeros((BLOCK_H, _G), dtype=tl.float32)
    if NUM_GROUPS >= 4:
        acc3 = tl.zeros((BLOCK_H, _G), dtype=tl.float32)

    k_offs = tl.arange(0, BLOCK_K)
    num_tiles = tl.cdiv(topk, BLOCK_K)

    for j in tl.range(0, num_tiles, num_stages=3):
        k_start = j * BLOCK_K
        k_pos = k_start + k_offs
        valid = k_pos < topk

        slot = tl.load(idx_ptr + t * topk + k_pos, mask=valid, other=0)
        valid = valid & (slot >= 0)
        page = tl.where(valid, slot, 0)
        if USE_I64_PAGE:
            page = page.to(tl.int64)

        kv_base = kv_ptr + page[:, None] * KV_DIM
        kv0 = tl.load(
            kv_base + g[None, :],
            mask=valid[:, None],
            other=0.0,
        ).to(input_type)
        if NUM_GROUPS >= 2:
            kv1 = tl.load(
                kv_base + (_G + g)[None, :],
                mask=valid[:, None],
                other=0.0,
            ).to(input_type)
        if NUM_GROUPS >= 3:
            kv2 = tl.load(
                kv_base + (2 * _G + g)[None, :],
                mask=valid[:, None],
                other=0.0,
            ).to(input_type)
        if NUM_GROUPS >= 4:
            kv3 = tl.load(
                kv_base + (3 * _G + g)[None, :],
                mask=valid[:, None],
                other=0.0,
            ).to(input_type)
        kv_tail = tl.load(
            kv_base + (D_V + dt)[None, :],
            mask=valid[:, None],
            other=0.0,
        ).to(input_type)

        scores = tl.dot(q0, tl.trans(kv0))
        if NUM_GROUPS >= 2:
            scores += tl.dot(q1, tl.trans(kv1))
        if NUM_GROUPS >= 3:
            scores += tl.dot(q2, tl.trans(kv2))
        if NUM_GROUPS >= 4:
            scores += tl.dot(q3, tl.trans(kv3))
        scores += tl.dot(q_tail, tl.trans(kv_tail))
        scores = scores * qk_scale
        scores = tl.where(valid[None, :], scores, neg_large)

        m_block = tl.max(scores, axis=1)
        m_new = tl.maximum(m_i, m_block)
        alpha = tl.exp2(m_i - m_new)
        p = tl.exp2(scores - m_new[:, None])
        l_new = l_i * alpha + tl.sum(p, axis=1)

        if USE_FP8_DOT:
            p_dot = (p * fp8_max).to(input_type)
        else:
            p_dot = p.to(input_type)
        acc0 = acc0 * alpha[:, None] + tl.dot(p_dot, kv0).to(tl.float32) * p_dot_scale
        if NUM_GROUPS >= 2:
            acc1 = (
                acc1 * alpha[:, None] + tl.dot(p_dot, kv1).to(tl.float32) * p_dot_scale
            )
        if NUM_GROUPS >= 3:
            acc2 = (
                acc2 * alpha[:, None] + tl.dot(p_dot, kv2).to(tl.float32) * p_dot_scale
            )
        if NUM_GROUPS >= 4:
            acc3 = (
                acc3 * alpha[:, None] + tl.dot(p_dot, kv3).to(tl.float32) * p_dot_scale
            )
        m_i = m_new
        l_i = l_new

    denom = tl.maximum(l_i, 1.0e-30)
    inv_denom = 1.0 / denom
    acc0 = tl.where(l_i[:, None] > 0.0, acc0 * inv_denom[:, None], 0.0)
    if NUM_GROUPS >= 2:
        acc1 = tl.where(l_i[:, None] > 0.0, acc1 * inv_denom[:, None], 0.0)
    if NUM_GROUPS >= 3:
        acc2 = tl.where(l_i[:, None] > 0.0, acc2 * inv_denom[:, None], 0.0)
    if NUM_GROUPS >= 4:
        acc3 = tl.where(l_i[:, None] > 0.0, acc3 * inv_denom[:, None], 0.0)

    o_base = out_ptr + t * H * D_V
    tl.store(
        o_base + h_offs[:, None] * D_V + g[None, :],
        acc0.to(tl.bfloat16),
        mask=h_mask[:, None],
    )
    if NUM_GROUPS >= 2:
        tl.store(
            o_base + h_offs[:, None] * D_V + (_G + g)[None, :],
            acc1.to(tl.bfloat16),
            mask=h_mask[:, None],
        )
    if NUM_GROUPS >= 3:
        tl.store(
            o_base + h_offs[:, None] * D_V + (2 * _G + g)[None, :],
            acc2.to(tl.bfloat16),
            mask=h_mask[:, None],
        )
    if NUM_GROUPS >= 4:
        tl.store(
            o_base + h_offs[:, None] * D_V + (3 * _G + g)[None, :],
            acc3.to(tl.bfloat16),
            mask=h_mask[:, None],
        )


@triton.jit
def _sparse_mla_decode_split_kernel(
    q_nope_ptr,  # [N, H, D_V]
    q_rope_ptr,  # [N, H, D_TAIL]
    kv_ptr,  # [num_pages, 1, KV_DIM]
    idx_ptr,  # [N, topk]
    lse_partial_ptr,  # [N, KV_SPLITS, H_padded]  fp32
    acc_partial_ptr,  # [N, KV_SPLITS, H_padded, D_V]  bf16
    qk_scale,
    fp8_max,
    topk: tl.constexpr,
    H: tl.constexpr,
    KV_DIM: tl.constexpr,
    D_V: tl.constexpr,
    D_TAIL: tl.constexpr,
    NUM_GROUPS: tl.constexpr,
    STRIDE_QN_T: tl.constexpr,
    STRIDE_QN_H: tl.constexpr,
    STRIDE_QR_T: tl.constexpr,
    STRIDE_QR_H: tl.constexpr,
    USE_FP8_DOT: tl.constexpr,
    KV_SPLITS: tl.constexpr,
    BLOCK_H: tl.constexpr,
    BLOCK_K: tl.constexpr,
):
    t = tl.program_id(0)
    pid_h = tl.program_id(1)
    pid_k = tl.program_id(2)

    h_offs = pid_h * BLOCK_H + tl.arange(0, BLOCK_H)
    h_mask = h_offs < H
    dt = tl.arange(0, D_TAIL)
    g = tl.arange(0, _G)

    input_type = kv_ptr.dtype.element_ty if USE_FP8_DOT else tl.bfloat16
    if USE_FP8_DOT:
        p_dot_scale = 1.0 / fp8_max
    else:
        p_dot_scale = 1.0

    qn_base = q_nope_ptr + t * STRIDE_QN_T
    qn_row = qn_base + h_offs[:, None] * STRIDE_QN_H
    q0 = tl.load(
        qn_row + g[None, :],
        mask=h_mask[:, None],
        other=0.0,
    ).to(input_type)
    if NUM_GROUPS >= 2:
        q1 = tl.load(
            qn_row + (_G + g)[None, :],
            mask=h_mask[:, None],
            other=0.0,
        ).to(input_type)
    if NUM_GROUPS >= 3:
        q2 = tl.load(
            qn_row + (2 * _G + g)[None, :],
            mask=h_mask[:, None],
            other=0.0,
        ).to(input_type)
    if NUM_GROUPS >= 4:
        q3 = tl.load(
            qn_row + (3 * _G + g)[None, :],
            mask=h_mask[:, None],
            other=0.0,
        ).to(input_type)
    q_tail = tl.load(
        q_rope_ptr + t * STRIDE_QR_T + h_offs[:, None] * STRIDE_QR_H + dt[None, :],
        mask=h_mask[:, None],
        other=0.0,
    ).to(input_type)

    tiles_per_segment = tl.cdiv(topk, KV_SPLITS * BLOCK_K)
    if pid_k * tiles_per_segment * BLOCK_K >= topk:
        return
    num_tiles = tl.cdiv(topk, BLOCK_K)
    tile_start = pid_k * tiles_per_segment
    tile_end = tl.minimum((pid_k + 1) * tiles_per_segment, num_tiles)

    neg_large = -3.4028234663852886e38
    m_i = tl.full((BLOCK_H,), neg_large, dtype=tl.float32)
    l_i = tl.zeros((BLOCK_H,), dtype=tl.float32)
    acc0 = tl.zeros((BLOCK_H, _G), dtype=tl.float32)
    if NUM_GROUPS >= 2:
        acc1 = tl.zeros((BLOCK_H, _G), dtype=tl.float32)
    if NUM_GROUPS >= 3:
        acc2 = tl.zeros((BLOCK_H, _G), dtype=tl.float32)
    if NUM_GROUPS >= 4:
        acc3 = tl.zeros((BLOCK_H, _G), dtype=tl.float32)

    k_offs = tl.arange(0, BLOCK_K)
    for j in tl.range(tile_start, tile_end, num_stages=3):
        k_start = j * BLOCK_K
        k_pos = k_start + k_offs
        valid = k_pos < topk

        slot = tl.load(idx_ptr + t * topk + k_pos, mask=valid, other=0)
        valid = valid & (slot >= 0)
        page = tl.where(valid, slot, 0).to(tl.int64)

        kv_base = kv_ptr + page[:, None] * KV_DIM
        kv0 = tl.load(
            kv_base + g[None, :],
            mask=valid[:, None],
            other=0.0,
        ).to(input_type)
        if NUM_GROUPS >= 2:
            kv1 = tl.load(
                kv_base + (_G + g)[None, :],
                mask=valid[:, None],
                other=0.0,
            ).to(input_type)
        if NUM_GROUPS >= 3:
            kv2 = tl.load(
                kv_base + (2 * _G + g)[None, :],
                mask=valid[:, None],
                other=0.0,
            ).to(input_type)
        if NUM_GROUPS >= 4:
            kv3 = tl.load(
                kv_base + (3 * _G + g)[None, :],
                mask=valid[:, None],
                other=0.0,
            ).to(input_type)
        kv_tail = tl.load(
            kv_base + (D_V + dt)[None, :],
            mask=valid[:, None],
            other=0.0,
        ).to(input_type)

        scores = tl.dot(q0, tl.trans(kv0))
        if NUM_GROUPS >= 2:
            scores += tl.dot(q1, tl.trans(kv1))
        if NUM_GROUPS >= 3:
            scores += tl.dot(q2, tl.trans(kv2))
        if NUM_GROUPS >= 4:
            scores += tl.dot(q3, tl.trans(kv3))
        scores += tl.dot(q_tail, tl.trans(kv_tail))
        scores = scores * qk_scale
        scores = tl.where(valid[None, :], scores, neg_large)

        m_block = tl.max(scores, axis=1)
        m_new = tl.maximum(m_i, m_block)
        alpha = tl.exp2(m_i - m_new)
        p = tl.exp2(scores - m_new[:, None])
        l_new = l_i * alpha + tl.sum(p, axis=1)

        if USE_FP8_DOT:
            p_dot = (p * fp8_max).to(input_type)
        else:
            p_dot = p.to(input_type)
        acc0 = acc0 * alpha[:, None] + tl.dot(p_dot, kv0).to(tl.float32) * p_dot_scale
        if NUM_GROUPS >= 2:
            acc1 = (
                acc1 * alpha[:, None] + tl.dot(p_dot, kv1).to(tl.float32) * p_dot_scale
            )
        if NUM_GROUPS >= 3:
            acc2 = (
                acc2 * alpha[:, None] + tl.dot(p_dot, kv2).to(tl.float32) * p_dot_scale
            )
        if NUM_GROUPS >= 4:
            acc3 = (
                acc3 * alpha[:, None] + tl.dot(p_dot, kv3).to(tl.float32) * p_dot_scale
            )
        m_i = m_new
        l_i = l_new

    neg_large = -1073741824.0
    denom = tl.maximum(l_i, 1.0e-30)
    inv_denom = 1.0 / denom
    has_data = l_i > 0.0
    acc0 = tl.where(has_data[:, None], acc0 * inv_denom[:, None], 0.0)
    if NUM_GROUPS >= 2:
        acc1 = tl.where(has_data[:, None], acc1 * inv_denom[:, None], 0.0)
    if NUM_GROUPS >= 3:
        acc2 = tl.where(has_data[:, None], acc2 * inv_denom[:, None], 0.0)
    if NUM_GROUPS >= 4:
        acc3 = tl.where(has_data[:, None], acc3 * inv_denom[:, None], 0.0)

    lse = tl.where(has_data, tl.log2(l_i) + m_i, neg_large)

    H_padded = tl.cdiv(H, BLOCK_H) * BLOCK_H
    lse_base = t * KV_SPLITS * H_padded + pid_k * H_padded
    tl.store(lse_partial_ptr + lse_base + h_offs, lse, mask=h_mask)

    ap_base = t * KV_SPLITS * H_padded * D_V + pid_k * H_padded * D_V
    tl.store(
        acc_partial_ptr + ap_base + h_offs[:, None] * D_V + g[None, :],
        acc0.to(tl.bfloat16),
        mask=h_mask[:, None],
    )
    if NUM_GROUPS >= 2:
        tl.store(
            acc_partial_ptr + ap_base + h_offs[:, None] * D_V + (_G + g)[None, :],
            acc1.to(tl.bfloat16),
            mask=h_mask[:, None],
        )
    if NUM_GROUPS >= 3:
        tl.store(
            acc_partial_ptr + ap_base + h_offs[:, None] * D_V + (2 * _G + g)[None, :],
            acc2.to(tl.bfloat16),
            mask=h_mask[:, None],
        )
    if NUM_GROUPS >= 4:
        tl.store(
            acc_partial_ptr + ap_base + h_offs[:, None] * D_V + (3 * _G + g)[None, :],
            acc3.to(tl.bfloat16),
            mask=h_mask[:, None],
        )


def triton_sparse_mla_decode_splitk(
    q_nope: torch.Tensor,
    q_rope: torch.Tensor,
    kv: torch.Tensor,
    indices: torch.Tensor,
    sm_scale: float,
    d_v: int = 512,
    kv_splits: int | None = None,
    workspace: _SplitKWorkspace | None = None,
) -> torch.Tensor:
    """Split-K Triton sparse MLA decode (DSv4 pattern).

    q_nope:  [bs, H, d_v] fp8/bf16
    q_rope:  [bs, H, d_tail] fp8/bf16
    kv:      [num_pages, 1, DIM] fp8/bf16
    indices: [bs, 1, topk] int32
    workspace: backend-owned grow-only split-K buffers for graph-safe reuse
    returns: [1, bs, H, d_v] bf16
    """
    is_fp8 = _validate_input_dtypes(q_nope, q_rope, kv)
    use_fp8_dot = is_fp8
    bs, H, d_v_in = q_nope.shape
    assert d_v_in == d_v
    d_tail = q_rope.shape[-1]
    kv_dim = kv.shape[-1]
    topk = indices.shape[-1]
    idx_flat = indices.squeeze(1).contiguous()
    # The kernels address q by explicit row strides, so a packed [N, H, D] layout
    # is not required -- only a unit-stride last dim. Callers that pass an
    # already-concatenated q (dsa_backend, GLM-5.2 path) hand us two strided views
    # of one [N, H, D_V + D_TAIL] buffer; copying those would cost two extra
    # device kernels per layer per forward for nothing.
    q_nope, stride_qn_t, stride_qn_h = _row_strides(q_nope)
    q_rope, stride_qr_t, stride_qr_h = _row_strides(q_rope)

    BLOCK_H = 16
    BLOCK_K = _sparse_mla_block_k(kv)
    n_head_blocks = (H + BLOCK_H - 1) // BLOCK_H
    h_padded = n_head_blocks * BLOCK_H

    assert d_v % 128 == 0, f"d_v must be divisible by 128, got {d_v}"
    num_groups = d_v // 128

    # Keep the number of split partials independent of a smaller LDS-safe
    # BLOCK_K. This retains the existing reduction cost on 64 KiB devices.
    max_kv_splits = max(1, topk // _PREFERRED_BLOCK_K)
    num_cu = _cu_count(q_nope.device)
    base_ctas = max(1, bs * n_head_blocks)
    optimize_gfx950_fp8 = H == 16 and _is_gfx950_sparse_mla_fp8(
        kv.dtype, H, d_v, d_tail, kv_dim
    )
    if optimize_gfx950_fp8:
        BLOCK_K, max_kv_splits = _gfx950_sparse_mla_decode_tile_config(
            base_ctas, topk, BLOCK_K, max_kv_splits
        )
    if kv_splits is None:
        # Very sparse BF16 launches benefit from enough split-K work to queue
        # two workgroups per CU. Once token/head parallelism is less sparse, keep the
        # one-wave target to avoid paying extra partial-output reduction cost.
        target_wg_per_cu = 1.0
        if not use_fp8_dot and base_ctas <= max(1, num_cu // 16):
            target_wg_per_cu = 2.0
        kv_splits = min(
            _kv_splits_heuristic(
                bs,
                H,
                BLOCK_H,
                num_cu=num_cu,
                target_wg_per_cu=target_wg_per_cu,
                max_kv_splits=max_kv_splits,
            ),
            max_kv_splits,
        )
        if optimize_gfx950_fp8:
            kv_splits = _gfx950_sparse_mla_kv_splits(
                base_ctas,
                topk,
                BLOCK_K,
                num_cu,
                kv_splits,
                max_kv_splits,
            )
    else:
        kv_splits = min(kv_splits, max_kv_splits)

    qk_scale = float(sm_scale) * LOG2E

    if kv_splits == 1:
        fused_num_warps = 4
        if optimize_gfx950_fp8:
            fused_num_warps = _gfx950_sparse_mla_num_warps(base_ctas, 1, num_cu)
        out = torch.empty(bs, H, d_v, device=q_nope.device, dtype=torch.bfloat16)
        with _no_async_copy():
            _sparse_mla_decode_fused_kernel[(bs, n_head_blocks)](
                q_nope,
                q_rope,
                kv,
                idx_flat,
                out,
                qk_scale,
                _FP8_MAX,
                topk=topk,
                H=H,
                KV_DIM=kv_dim,
                D_V=d_v,
                D_TAIL=d_tail,
                NUM_GROUPS=num_groups,
                STRIDE_QN_T=stride_qn_t,
                STRIDE_QN_H=stride_qn_h,
                STRIDE_QR_T=stride_qr_t,
                STRIDE_QR_H=stride_qr_h,
                USE_FP8_DOT=use_fp8_dot,
                BLOCK_H=BLOCK_H,
                BLOCK_K=BLOCK_K,
                USE_I64_PAGE=not (
                    optimize_gfx950_fp8
                    and fused_num_warps == 2
                    and topk >= 2048
                    and _page_offsets_fit_i32(kv.shape[0], kv_dim)
                ),
                num_warps=fused_num_warps,
                num_stages=2,
            )
        return out.unsqueeze(0)

    tiles_per_split = (topk + kv_splits * BLOCK_K - 1) // (kv_splits * BLOCK_K)
    active_splits = (topk + tiles_per_split * BLOCK_K - 1) // (
        tiles_per_split * BLOCK_K
    )
    active_splits = min(active_splits, kv_splits)
    split_num_warps = 4
    if optimize_gfx950_fp8:
        split_num_warps = _gfx950_sparse_mla_num_warps(base_ctas, active_splits, num_cu)

    lse_partial, acc_partial = _get_splitk_bufs(
        bs, kv_splits, h_padded, d_v, q_nope.device, workspace
    )
    out = torch.empty(bs, H, d_v, device=q_nope.device, dtype=torch.bfloat16)

    grid_split = (bs, n_head_blocks, kv_splits)
    with _no_async_copy():
        _sparse_mla_decode_split_kernel[grid_split](
            q_nope,
            q_rope,
            kv,
            idx_flat,
            lse_partial,
            acc_partial,
            qk_scale,
            _FP8_MAX,
            topk=topk,
            H=H,
            KV_DIM=kv_dim,
            D_V=d_v,
            D_TAIL=d_tail,
            NUM_GROUPS=num_groups,
            STRIDE_QN_T=stride_qn_t,
            STRIDE_QN_H=stride_qn_h,
            STRIDE_QR_T=stride_qr_t,
            STRIDE_QR_H=stride_qr_h,
            USE_FP8_DOT=use_fp8_dot,
            KV_SPLITS=kv_splits,
            BLOCK_H=BLOCK_H,
            BLOCK_K=BLOCK_K,
            num_warps=split_num_warps,
            num_stages=2,
        )

    D_CHUNK = _reduce_d_chunk(active_splits, bs * H) if optimize_gfx950_fp8 else 64
    grid_reduce = (bs, H, (d_v + D_CHUNK - 1) // D_CHUNK)
    _sparse_mla_reduce_kernel[grid_reduce](
        lse_partial,
        acc_partial,
        out,
        H=H,
        D_V=d_v,
        KV_SPLITS=kv_splits,
        ACTIVE_SPLITS=active_splits,
        ACTIVE_SPLITS_POW2=_next_pow2(active_splits),
        D_CHUNK=D_CHUNK,
        BLOCK_K=BLOCK_K,
        num_warps=4,
    )
    return out.unsqueeze(0)


# ---------------------------------------------------------------------------
# Convenience: auto-select best variant
# ---------------------------------------------------------------------------


def triton_sparse_mla_decode(
    q_nope: torch.Tensor,
    q_rope: torch.Tensor,
    kv: torch.Tensor,
    indices: torch.Tensor,
    sm_scale: float,
    d_v: int = 512,
) -> torch.Tensor:
    return triton_sparse_mla_decode_splitk(q_nope, q_rope, kv, indices, sm_scale, d_v)
