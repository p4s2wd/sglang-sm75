/// \file source_location.h
/// \brief Portable `source_location` wrapper.
///
/// Uses `std::source_location` when available (C++20), otherwise falls
/// back to a minimal stub that returns empty/zero values.

#pragma once
#include <version>

#if defined(__cpp_lib_source_location)
#include <source_location>
#endif

namespace sglang {

/// NOTE: fallback to a minimal source_location implementation
#if defined(__cpp_lib_source_location)

using source_location_t = std::source_location;

#else

struct source_location_fallback {
 public:
  static constexpr source_location_fallback current() noexcept {
    return source_location_fallback{};
  }
  constexpr source_location_fallback() noexcept = default;
  constexpr unsigned line() const noexcept {
    return 0;
  }
  constexpr unsigned column() const noexcept {
    return 0;
  }
  constexpr const char* file_name() const noexcept {
    return "";
  }
  constexpr const char* function_name() const noexcept {
    return "";
  }
};

using source_location_t = source_location_fallback;

#endif

}  // namespace sglang
