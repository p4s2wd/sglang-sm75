#pragma once

#include <sgl_kernel/tensor.h>

#include <sgl_kernel/runtime.cuh>
#include <sgl_kernel/type.cuh>
#include <sgl_kernel/utils.cuh>
#include <sgl_kernel/vec.cuh>
#include <sgl_kernel/warp.cuh>

#include <algorithm>
#include <cstdint>

namespace sglang {

namespace qwen_qkv_epilogue {

constexpr int kHeadDim = 128;
constexpr int kThreads = 256;
constexpr int kWarps = kThreads / device::kWarpThreads;
constexpr int kElemsPerThread = kHeadDim / device::kWarpThreads;
constexpr int kVecSize = kElemsPerThread / 2;

struct Params {
  void* joint_q;
  void* joint_k;
  void* joint_v;
  const void* img_q;
  const void* img_k;
  const void* img_v;
  const void* txt_q;
  const void* txt_k;
  const void* txt_v;
  const void* img_q_weight;
  const void* img_k_weight;
  const void* txt_q_weight;
  const void* txt_k_weight;
  const void* img_cache;
  const void* txt_cache;
  int64_t img_token_stride_bytes;
  int64_t txt_token_stride_bytes;
  int64_t output_token_stride_bytes;
  int64_t head_stride_bytes;
  uint32_t img_tokens;
  uint32_t txt_tokens;
  uint32_t num_heads;
  float img_eps;
  float txt_eps;
};

__global__ void qwen_qkv_epilogue_kernel(const Params __grid_constant__ params) {
  using namespace device;
  using Packed = packed_t<bf16_t>;
  using Storage = AlignedVector<Packed, kVecSize>;

  const uint32_t lane = threadIdx.x % kWarpThreads;
  const uint32_t warp = threadIdx.x / kWarpThreads;
  const uint32_t start = blockIdx.x * kWarps + warp;
  const uint32_t workers = gridDim.x * kWarps;
  const uint32_t total_tokens = params.txt_tokens + params.img_tokens;
  const uint32_t kind = blockIdx.y;  // Q, K, and V have independent grids.
  const bool is_value = kind == 2;
  const uint32_t v_heads = div_ceil(params.num_heads, uint32_t(2));
  const uint32_t heads_per_token = is_value ? v_heads : params.num_heads;
  const uint32_t total_works = total_tokens * heads_per_token;

  for (uint32_t work = start; work < total_works; work += workers) {
    const uint32_t joint_token = work / heads_per_token;
    const uint32_t head = (work % heads_per_token) * (is_value ? 2 : 1);
    const bool is_text = joint_token < params.txt_tokens;
    const uint32_t source_token = is_text ? joint_token : joint_token - params.txt_tokens;

    const void* input_base;
    void* output_base;
    if (kind == 0) {
      input_base = is_text ? params.txt_q : params.img_q;
      output_base = params.joint_q;
    } else if (kind == 1) {
      input_base = is_text ? params.txt_k : params.img_k;
      output_base = params.joint_k;
    } else {
      input_base = is_text ? params.txt_v : params.img_v;
      output_base = params.joint_v;
    }

    const auto input_token_stride_bytes = is_text ? params.txt_token_stride_bytes : params.img_token_stride_bytes;
    const void* input =
        pointer::offset(input_base, source_token * input_token_stride_bytes, head * params.head_stride_bytes);
    void* output =
        pointer::offset(output_base, joint_token * params.output_token_stride_bytes, head * params.head_stride_bytes);

    if (kind == 2) {
      // One warp copies two adjacent heads, keeping all V workers active while
      // issuing twice as many bytes per memory instruction.
      if (head + 1 < params.num_heads) {
        using CopyStorage = AlignedVector<Packed, 2 * kVecSize>;
        const auto input_vec = load_as<CopyStorage>(input, lane);
        store_as<CopyStorage>(output, input_vec, lane);
      } else {
        const auto input_vec = load_as<Storage>(input, lane);
        store_as<Storage>(output, input_vec, lane);
      }
      continue;
    }
    auto input_vec = load_as<Storage>(input, lane);

    const void* weight_base;
    if (kind == 0) {
      weight_base = is_text ? params.txt_q_weight : params.img_q_weight;
    } else {
      weight_base = is_text ? params.txt_k_weight : params.img_k_weight;
    }
    const auto weight_vec = load_as<Storage>(weight_base, lane);

    float elems[kElemsPerThread];
    float sum_of_squares = 0.0f;
#pragma unroll
    for (uint32_t j = 0; j < kVecSize; ++j) {
      const auto [x0, x1] = cast<fp32x2_t>(input_vec[j]);
      elems[2 * j] = x0;
      elems[2 * j + 1] = x1;
      sum_of_squares += x0 * x0 + x1 * x1;
    }
    sum_of_squares = warp::reduce_sum(sum_of_squares);
    const float eps = is_text ? params.txt_eps : params.img_eps;
    const float norm_factor = math::rsqrt(sum_of_squares / static_cast<float>(kHeadDim) + eps);

#pragma unroll
    for (uint32_t j = 0; j < kVecSize; ++j) {
      const auto [w0, w1] = cast<fp32x2_t>(weight_vec[j]);
      elems[2 * j] *= norm_factor * w0;
      elems[2 * j + 1] *= norm_factor * w1;
    }

    const auto* cache = static_cast<const float*>(is_text ? params.txt_cache : params.img_cache);
    const auto* cos_ptr = cache + source_token * kHeadDim;
    const auto* sin_ptr = cos_ptr + kHeadDim / 2;
    // Each lane consumes two adjacent cache entries. Loading them together
    // avoids the half-used sectors from two stride-2 scalar loads.
    const auto cos_pair = __ldg(reinterpret_cast<const float2*>(cos_ptr) + lane);
    const auto sin_pair = __ldg(reinterpret_cast<const float2*>(sin_ptr) + lane);
#pragma unroll
    for (uint32_t i = 0; i < kElemsPerThread; i += 2) {
      const float x = elems[i];
      const float y = elems[i + 1];
      const float cos = i == 0 ? cos_pair.x : cos_pair.y;
      const float sin = i == 0 ? sin_pair.x : sin_pair.y;
      // Preserve the original QKNorm/RoPE contraction: round the sin product
      // before adding it to the fused cos product, including for vector loads.
      elems[i] = __fmaf_rn(x, cos, -__fmul_rn(y, sin));
      elems[i + 1] = __fmaf_rn(y, cos, __fmul_rn(x, sin));
    }

#pragma unroll
    for (uint32_t j = 0; j < kVecSize; ++j) {
      input_vec[j] = cast<Packed, fp32x2_t>({elems[2 * j], elems[2 * j + 1]});
    }
    store_as<Storage>(output, input_vec, lane);
  }
}

struct QwenQKVEpilogueKernel {
  static void
  run(tvm::ffi::TensorView joint_q,
      tvm::ffi::TensorView joint_k,
      tvm::ffi::TensorView joint_v,
      tvm::ffi::TensorView img_q,
      tvm::ffi::TensorView img_k,
      tvm::ffi::TensorView img_v,
      tvm::ffi::TensorView txt_q,
      tvm::ffi::TensorView txt_k,
      tvm::ffi::TensorView txt_v,
      tvm::ffi::TensorView img_q_weight,
      tvm::ffi::TensorView img_k_weight,
      tvm::ffi::TensorView txt_q_weight,
      tvm::ffi::TensorView txt_k_weight,
      tvm::ffi::TensorView img_cache,
      tvm::ffi::TensorView txt_cache,
      double img_eps,
      double txt_eps) {
    using namespace host;

    auto NI = SymbolicSize{"img_tokens"};
    auto NT = SymbolicSize{"txt_tokens"};
    auto N = SymbolicSize{"joint_tokens"};
    auto H = SymbolicSize{"num_heads"};
    auto D = SymbolicSize{"head_dim"};
    auto device = SymbolicDevice{};
    D.set_value(kHeadDim);
    device.set_options<kDLCUDA>();

    TensorMatcher({NI, H, D})
        .with_strides({-1, D, 1})
        .with_dtype<bf16_t>()
        .with_device(device)
        .verify(img_q)
        .verify(img_k)
        .verify(img_v);
    TensorMatcher({NT, H, D})
        .with_strides({-1, D, 1})
        .with_dtype<bf16_t>()
        .with_device(device)
        .verify(txt_q)
        .verify(txt_k)
        .verify(txt_v);
    N.set_value(NI.unwrap() + NT.unwrap());
    TensorMatcher({N, H, D}).with_dtype<bf16_t>().with_device(device).verify(joint_q).verify(joint_k).verify(joint_v);
    TensorMatcher({D})
        .with_dtype<bf16_t>()
        .with_device(device)
        .verify(img_q_weight)
        .verify(img_k_weight)
        .verify(txt_q_weight)
        .verify(txt_k_weight);
    TensorMatcher({-1, D}).with_dtype<fp32_t>().with_device(device).verify(img_cache);
    TensorMatcher({-1, D}).with_dtype<fp32_t>().with_device(device).verify(txt_cache);

    RuntimeCheck(
        img_q.stride(0) == img_k.stride(0) && img_q.stride(0) == img_v.stride(0),
        "image QKV inputs must use the same token stride");
    RuntimeCheck(
        txt_q.stride(0) == txt_k.stride(0) && txt_q.stride(0) == txt_v.stride(0),
        "text QKV inputs must use the same token stride");
    RuntimeCheck(
        img_q.stride(1) == kHeadDim && img_k.stride(1) == kHeadDim && img_v.stride(1) == kHeadDim,
        "image QKV heads must be contiguous");
    RuntimeCheck(
        txt_q.stride(1) == kHeadDim && txt_k.stride(1) == kHeadDim && txt_v.stride(1) == kHeadDim,
        "text QKV heads must be contiguous");
    RuntimeCheck(joint_q.is_contiguous(), "joint QKV outputs must be contiguous");
    RuntimeCheck(joint_k.is_contiguous(), "joint QKV outputs must be contiguous");
    RuntimeCheck(joint_v.is_contiguous(), "joint QKV outputs must be contiguous");
    RuntimeCheck(img_cache.size(0) >= NI.unwrap(), "img cache is shorter than img tokens");
    RuntimeCheck(txt_cache.size(0) >= NT.unwrap(), "txt cache is shorter than txt tokens");

    const uint32_t img_tokens = static_cast<uint32_t>(NI.unwrap());
    const uint32_t txt_tokens = static_cast<uint32_t>(NT.unwrap());
    const uint32_t num_heads = static_cast<uint32_t>(H.unwrap());
    const uint32_t total_works = (img_tokens + txt_tokens) * num_heads;
    if (total_works == 0) return;

    const int64_t head_stride_bytes = kHeadDim * sizeof(bf16_t);
    const int64_t output_token_stride_bytes = num_heads * head_stride_bytes;
    const auto params = Params{
        .joint_q = joint_q.data_ptr(),
        .joint_k = joint_k.data_ptr(),
        .joint_v = joint_v.data_ptr(),
        .img_q = img_q.data_ptr(),
        .img_k = img_k.data_ptr(),
        .img_v = img_v.data_ptr(),
        .txt_q = txt_q.data_ptr(),
        .txt_k = txt_k.data_ptr(),
        .txt_v = txt_v.data_ptr(),
        .img_q_weight = img_q_weight.data_ptr(),
        .img_k_weight = img_k_weight.data_ptr(),
        .txt_q_weight = txt_q_weight.data_ptr(),
        .txt_k_weight = txt_k_weight.data_ptr(),
        .img_cache = img_cache.data_ptr(),
        .txt_cache = txt_cache.data_ptr(),
        .img_token_stride_bytes = img_q.stride(0) * sizeof(bf16_t),
        .txt_token_stride_bytes = txt_q.stride(0) * sizeof(bf16_t),
        .output_token_stride_bytes = output_token_stride_bytes,
        .head_stride_bytes = head_stride_bytes,
        .img_tokens = img_tokens,
        .txt_tokens = txt_tokens,
        .num_heads = num_heads,
        .img_eps = static_cast<float>(img_eps),
        .txt_eps = static_cast<float>(txt_eps),
    };

    const uint32_t sm_count = runtime::get_sm_count(device.unwrap().device_id);
    static const uint32_t blocks_per_sm = runtime::get_blocks_per_sm(qwen_qkv_epilogue_kernel, kThreads);
    const uint32_t needed_blocks = div_ceil(total_works, uint32_t(kWarps));
    const uint32_t blocks = std::min(blocks_per_sm * sm_count, needed_blocks);
    LaunchKernel(dim3(blocks, 3), kThreads, device.unwrap())(qwen_qkv_epilogue_kernel, params);
  }
};

}  // namespace qwen_qkv_epilogue

}  // namespace sglang
