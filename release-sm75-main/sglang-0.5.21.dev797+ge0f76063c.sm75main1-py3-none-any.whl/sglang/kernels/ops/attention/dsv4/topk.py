from __future__ import annotations

from typing import Optional

import torch
import triton
import triton.language as tl

from sglang.kernels.jit.utils import (
    cache_once,
    is_arch_support_pdl,
    is_hip_runtime,
    load_jit,
    make_cpp_args,
)
from sglang.srt.utils import is_xpu

from .candidate_table import CANDIDATE_BLOCK_SIZE
from .utils import make_name


@cache_once
def _jit_topk_v1_module():
    args = make_cpp_args(is_arch_support_pdl())
    return load_jit(
        make_name("topk_v1"),
        *args,
        cuda_files=["deepseek_v4/topk_v1.cuh"],
        cuda_wrappers=[("topk_transform", f"TopKKernel<{args}>::transform")],
    )


@cache_once
def _jit_topk_v2_module():
    from sglang.kernels.jit.utils.occupancy import (
        NoSchedulableClustersError,
        get_max_active_clusters,
    )

    args = make_cpp_args(is_arch_support_pdl())
    # Enable each cluster path only when its occupancy probe reports capacity.
    extra_cuda_cflags = []
    if is_arch_support_pdl():  # set the persistent cluster size after hopper
        for cluster_size, occupancy in ((8, 2), (16, 1)):
            try:
                max_active_clusters = get_max_active_clusters(
                    cluster_size, occupancy=occupancy
                )
            except NoSchedulableClustersError:
                max_active_clusters = 0
            extra_cuda_cflags.append(
                f"-DSGL_TOPK_V2_MAX_C{cluster_size}_OCC{occupancy}={max_active_clusters}"
            )
    kernel = f"TopKKernel<{args}>"
    wrappers = [
        ("topk_transform_paged", f"{kernel}::transform_paged"),
        ("topk_transform_ragged", f"{kernel}::transform_ragged"),
        ("topk_plan", f"{kernel}::plan"),
    ]
    if is_hip_runtime():
        # transform_packed only exists under USE_ROCM, see topk_v2.cuh
        wrappers.append(("topk_transform_packed", f"{kernel}::transform_packed"))
    return load_jit(
        make_name("topk_v2"),
        *args,
        extra_cuda_cflags=extra_cuda_cflags,
        cuda_files=["deepseek_v4/topk_v2.cuh"],
        cuda_wrappers=wrappers,
    )


@cache_once
def _jit_topk_bf16_small_module():
    args = make_cpp_args(is_arch_support_pdl())
    return load_jit(
        make_name("topk_bf16_small"),
        *args,
        cuda_files=["deepseek_v4/topk_bf16_small.cuh"],
        cuda_wrappers=[("topk_transform", f"TopKBF16Kernel<{args}>::transform")],
    )


def topk_transform_bf16_small(
    scores: torch.Tensor,
    seq_lens: torch.Tensor,
    page_table: torch.Tensor,
    out_page_indices: torch.Tensor,
    page_size: int,
) -> None:
    """bf16 top-k for rows of at most 16384 scores (the DeepSeek-V4.1 sparse
    indexer's consumer rows), fused with a page-table transform.

    Row ``b`` selects the ``k = out_page_indices.shape[1]`` best of its first
    ``seq_lens[b]`` scores (``k`` at most 2048); a selected index ``i`` is
    written as ``page_table[b, i // page_size] * page_size + i % page_size``,
    in no particular order, and ``-1`` fills the slots past
    ``min(k, seq_lens[b])``. Selection is exact (two radix passes over the raw
    bf16 bytes locate the k-th largest value); which of the elements equal to
    it fill the last slots is arbitrary. NaN scores are not supported.
    """
    _jit_topk_bf16_small_module().topk_transform(
        scores, seq_lens, page_table, out_page_indices, page_size
    )


@triton.jit
def _topk_transform_paged_triton_kernel(
    scores_ptr,
    seq_lens_ptr,
    page_tables_ptr,
    out_page_indices_ptr,
    out_raw_indices_ptr,
    max_seq_len,
    stride_scores,
    page_table_width,
    stride_page_tables,
    K: tl.constexpr,
    K_POW2: tl.constexpr,
    BLOCK_N: tl.constexpr,
    PAGE_SIZE: tl.constexpr,
    WRITE_RAW: tl.constexpr,
):
    row = tl.program_id(0)
    seq_len = tl.load(seq_lens_ptr + row)
    offs_n = tl.arange(0, BLOCK_N)
    acc = tl.zeros((K_POW2,), dtype=tl.uint64)
    for start in range(0, seq_len, BLOCK_N):
        cols = start + offs_n
        valid = cols < seq_len
        score = tl.load(
            scores_ptr + row * stride_scores + cols,
            mask=valid,
            other=float("-inf"),
        )
        score_bits = score.to(tl.uint32, bitcast=True)
        sign = tl.full(score_bits.shape, 0x80000000, tl.uint32)
        key = tl.where(
            (score_bits & sign) != 0,
            ~score_bits,
            score_bits ^ sign,
        )
        packed = (key.to(tl.uint64) << 32) | cols.to(tl.uint64)
        candidate = tl.topk(packed, K_POW2, dim=0)
        acc = tl.bitonic_merge(acc)
        acc = tl.maximum(acc, tl.topk(candidate, K_POW2, dim=0))
    acc = tl.sort(acc, descending=True)
    offs_k = tl.arange(0, K_POW2)
    raw = (acc & 0xFFFFFFFF).to(tl.int32)
    valid = (offs_k < K) & (offs_k < seq_len)
    page_ids = raw // PAGE_SIZE
    page_ids = tl.where(valid, page_ids, 0)
    pages = tl.load(
        page_tables_ptr + row * stride_page_tables + page_ids,
        mask=valid,
        other=0,
    )
    page_indices = pages * PAGE_SIZE + raw % PAGE_SIZE
    page_indices = tl.where(valid, page_indices, -1).to(tl.int32)
    tl.store(
        out_page_indices_ptr + row * K + offs_k,
        page_indices,
        mask=offs_k < K,
    )
    if WRITE_RAW:
        raw = tl.where(valid, raw, -1)
        tl.store(
            out_raw_indices_ptr + row * K + offs_k,
            raw,
            mask=offs_k < K,
        )


def topk_transform_paged_triton(
    scores: torch.Tensor,
    seq_lens: torch.Tensor,
    page_tables: torch.Tensor,
    out_page_indices: torch.Tensor,
    page_size: int,
    out_raw_indices: Optional[torch.Tensor] = None,
) -> None:
    assert scores.ndim == 2
    assert scores.dtype == torch.float32
    assert scores.stride(1) == 1
    assert scores.stride(0) > 0
    assert seq_lens.ndim == 1 and seq_lens.shape[0] == scores.shape[0]
    assert page_tables.ndim == 2 and page_tables.shape[0] == scores.shape[0]
    assert page_tables.stride(1) == 1
    assert out_page_indices.ndim == 2
    assert out_page_indices.shape[0] == scores.shape[0]
    assert out_page_indices.dtype == torch.int32
    K = out_page_indices.shape[1]
    K_POW2 = triton.next_power_of_2(K)
    assert 0 < K <= 1024
    assert page_size > 0
    assert page_size & (page_size - 1) == 0
    if out_raw_indices is None:
        raw_indices = out_page_indices
        write_raw = False
    else:
        raw_indices = out_raw_indices
        assert raw_indices.shape == out_page_indices.shape
        assert raw_indices.dtype == torch.int32
        write_raw = True
    BLOCK_N = max(256, min(K_POW2, 1024))
    grid = (scores.shape[0],)
    _topk_transform_paged_triton_kernel[grid](
        scores,
        seq_lens,
        page_tables,
        out_page_indices,
        raw_indices,
        scores.shape[1],
        scores.stride(0),
        page_tables.shape[1],
        page_tables.stride(0),
        K=K,
        K_POW2=K_POW2,
        BLOCK_N=BLOCK_N,
        PAGE_SIZE=page_size,
        WRITE_RAW=write_raw,
        num_warps=4,
        num_stages=1,
    )


def topk_transform_paged(
    scores: torch.Tensor,
    seq_lens: torch.Tensor,
    page_tables: torch.Tensor,
    out_page_indices: torch.Tensor,
    page_size: int,
    out_raw_indices: Optional[torch.Tensor] = None,
) -> None:
    if is_hip_runtime():
        torch.ops.sgl_kernel.deepseek_v4_topk_transform_512(
            scores, seq_lens, page_tables, out_page_indices, page_size, out_raw_indices
        )
    elif is_xpu():
        torch.ops.sgl_kernel.topk_transform(
            scores, seq_lens, page_tables, out_page_indices, page_size, out_raw_indices
        )
    else:
        module = _jit_topk_v1_module()
        module.topk_transform(
            scores, seq_lens, page_tables, out_page_indices, page_size, out_raw_indices
        )


def topk_transform_paged_torch(
    scores: torch.Tensor,
    seq_lens: torch.Tensor,
    page_tables: torch.Tensor,
    out_page_indices: torch.Tensor,
    page_size: int,
    out_raw_indices: Optional[torch.Tensor] = None,
) -> None:
    """The torch ``topk_transform_paged``: top-``k`` (``k = out_page_indices.shape[1]``)
    of each row within its first ``seq_lens[b]`` columns, ascending, as pool slots
    through ``page_tables`` and as positions when given; ``-1`` padded."""
    topk = out_page_indices.shape[1]
    columns = torch.arange(scores.shape[1], device=seq_lens.device)
    lens_c = seq_lens.unsqueeze(-1)
    # Columns past a row's length hold garbage.
    s = scores.masked_fill(columns[None, :] >= lens_c, -torch.inf)
    idx = s.topk(topk, dim=-1, sorted=False).indices.sort(dim=-1).values
    reach = idx < lens_c
    slots = page_tables.gather(-1, idx // page_size) * page_size + (idx % page_size)
    out_page_indices.copy_(torch.where(reach, slots, -1).to(torch.int32))
    if out_raw_indices is not None:
        out_raw_indices.copy_(torch.where(reach, idx, -1).to(torch.int32))


# metadata is (batch+1, 2) int32: row 0 = {cluster_threshold, num_cluster_items};
# rows 1..N = {batch_id, seq_len} of items routed to the persistent cluster pool.
_PLAN_METADATA_INTS_PER_BATCH = 2


def plan_topk_v2(seq_lens: torch.Tensor, static_threshold: int = -1) -> torch.Tensor:
    """
    Preprocess the per-batch routing plan for :func:`topk_transform_paged_v2`.
    NOTE: every entry of ``seq_lens`` must be NON-NEGATIVE.

    :param static_threshold: If a batch item has `seq_len` > `static_threshold`,
                             prefer the cluster implementation.
                             Negative number means internal heuristic.
    """
    module = _jit_topk_v2_module()
    bs = seq_lens.shape[0]
    metadata = seq_lens.new_empty(bs + 1, _PLAN_METADATA_INTS_PER_BATCH)
    module.topk_plan(seq_lens, metadata, static_threshold)
    return metadata


def topk_v2_plan_is_written(seq_lens: torch.Tensor) -> bool:
    """Whether :func:`plan_topk_v2` writes a plan for these lengths. Small
    batches and devices without clusters leave the plan buffer untouched."""
    probe = torch.full(
        (seq_lens.shape[0] + 1, _PLAN_METADATA_INTS_PER_BATCH),
        -1,
        dtype=torch.int32,
        device=seq_lens.device,
    )
    _jit_topk_v2_module().topk_plan(seq_lens, probe, -1)
    return probe[0, 1].item() != -1


def topk_transform_ragged_v2(
    scores: torch.Tensor,
    seq_lens: torch.Tensor,
    *,
    out_offsets: torch.Tensor,
    out_indices: torch.Tensor,
    row_starts: Optional[torch.Tensor] = None,
) -> None:
    """Ragged (prefill) fused top-k for a contiguous-KV score matrix.

    Row ``i`` selects the top-k of ``scores[i, ks : ks + seq_lens[i]]`` (``ks =
    row_starts[i]``, 0 when ``row_starts`` is omitted) and writes
    ``selected_position + out_offsets[i]`` into ``out_indices``, ``-1`` padded.
    With the production convention ``out_offsets == row_starts`` that is the
    column index itself, i.e. the token's slot in the batch's flattened KV.

    Unlike :func:`topk_transform_paged_v2` this needs no page table and no plan
    (the cluster path only pays off for very few rows, and prefill has many).

    NOTE: ``scores`` is written in place -- the <= 3 columns ahead of each
    row's window that the 16-byte-aligned read base pulls in are masked out.
    They are invalid for that row and the buffer must have no other consumer.
    ``seq_lens`` entries must be NON-NEGATIVE, as for the paged entry point.
    """
    if is_xpu():
        torch.ops.sgl_kernel.topk_transform_ragged(
            scores,
            seq_lens,
            out_indices,
            out_offsets,
            row_starts,
        )
        return
    module = _jit_topk_v2_module()
    module.topk_transform_ragged(scores, seq_lens, row_starts, out_offsets, out_indices)


def topk_transform_paged_v2(
    scores: torch.Tensor,
    seq_lens: torch.Tensor,
    page_tables: Optional[torch.Tensor],
    out_page_indices: torch.Tensor,
    page_size: int,
    metadata: torch.Tensor,
    out_raw_indices: Optional[torch.Tensor] = None,
) -> None:
    """Fused top-k + optional page-table transform (DeepSeek-V4 top-k v2 kernel).

    Output mode is chosen from ``page_tables`` and ``out_raw_indices`` and
    resolved to a device-side template parameter, so an unused page-table gather
    is compiled out rather than skipped at runtime:

    * ``page_tables=None`` -- ``out_page_indices`` receives the raw selected
      indices and no page table is read.
    * ``page_tables`` given -- ``out_page_indices`` receives the page-table
      transform of them.
    * Both outputs given -- ``out_page_indices`` receives the page-table
      transform and ``out_raw_indices`` receives the selected raw indices.

    For the packed (DSA extend prefill) layout see
    :func:`topk_transform_packed_v2`.

    NOTE: every entry of `seq_lens` must be NON-NEGATIVE, and `metadata` must
    come from :func:`plan_topk_v2` over the same `seq_lens` values.
    A length of 0 is the valid way to express "no tokens": the row takes the
    trivial path and the output is guaranteed to be all -1.
    """
    if is_xpu():
        if out_raw_indices is not None:
            topk_transform_paged(
                scores,
                seq_lens,
                page_tables,
                out_page_indices,
                page_size,
                out_raw_indices,
            )
            return
        torch.ops.sgl_kernel.topk_transform_paged(
            scores,
            seq_lens,
            page_tables,
            out_page_indices,
            page_size,
            metadata,
        )
        return
    module = _jit_topk_v2_module()
    module.topk_transform_paged(
        scores,
        seq_lens,
        page_tables,
        out_page_indices,
        page_size,
        metadata,
        out_raw_indices,
    )


def topk_transform_packed_v2(
    scores: torch.Tensor,
    seq_lens: torch.Tensor,
    page_tables: torch.Tensor,
    out_page_indices: torch.Tensor,
    page_size: int,
    *,
    row_starts: torch.Tensor,
    row_to_batch: Optional[torch.Tensor] = None,
) -> None:
    """Packed (DSA extend prefill) fused top-k + page-table transform.

    Row ``i`` selects the top-k of ``scores[i, ks : ks + seq_lens[i]]``
    (``ks = row_starts[i]``) and writes the page-table transform of the selected
    row-local positions into ``out_page_indices``, ``-1`` padded. Prefill expands
    one request into many query-token rows, so ``row_to_batch[i]`` (optional,
    ``(rows,)`` int32) names the ``page_tables`` row of the request row ``i``
    belongs to; omitting it indexes the table by score row. ``row_to_batch`` is
    not range-checked.

    This is :func:`topk_transform_ragged_v2` with a page-table output instead of
    an additive offset. Like ragged, it dispatches the implementation per row at
    runtime, so it needs no plan and no :func:`plan_topk_v2` metadata.

    NOTE: ``scores`` is MODIFIED IN PLACE -- the <= 3 columns ahead of each row's
    window that the 16-byte-aligned read base pulls in are masked out. They are
    invalid for that row and the buffer must have no other consumer, so do not
    pass a view with overlapping rows.
    ``seq_lens`` entries must be NON-NEGATIVE, as for the paged entry point.

    ROCm only: the kernel is compiled under ``USE_ROCM`` so that CUDA and XPU
    builds are untouched. Nothing in it is AMD-specific -- no non-ROCm caller
    produces this layout today.
    """
    assert is_hip_runtime(), "topk_transform_packed_v2 is compiled under USE_ROCM only"
    module = _jit_topk_v2_module()
    module.topk_transform_packed(
        scores,
        seq_lens,
        row_starts,
        page_tables,
        out_page_indices,
        page_size,
        row_to_batch,
    )


def topk_transform_sparse(
    logits: torch.Tensor,
    valid_lens: torch.Tensor,
    blocks: torch.Tensor,
    out_indices: torch.Tensor,
) -> None:
    """Top-``k`` (``k = out_indices.shape[1]``) of each row of the bf16 sparse
    ``logits`` within its first ``valid_lens[b]`` columns, ``-1`` padded, unordered;
    column ``j`` is written as ``blocks[b, j // 8] * 8 + j % 8``: pool slots for the
    published blocks as pool slots / 8, compressed positions for logical ids."""
    topk_transform_bf16_small(
        logits, valid_lens, blocks, out_indices, CANDIDATE_BLOCK_SIZE
    )
